<?php get_header(); ?>

<h1> singular.php</h1>
<?php get_footer(); ?>